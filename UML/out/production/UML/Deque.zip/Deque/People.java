package Deque;

public class People {
    private int index;
    private int age;
    private String name;

    public People(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void inQueue() {
        System.out.println(String.format("%s aged %d is in queue", name, age));
    }

    public void outQueue() {
        System.out.println(String.format("%s aged %d is moving out queue", name, age));
    }

    public int getAge() {
        return age;
    }
}
