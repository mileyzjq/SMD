package Deque;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Deque;

public class WaitInQueue {
    private Deque<People> queue;
    private static final int SENIOR_AGE = 60;

    public WaitInQueue() {
        queue = new LinkedList<>();
    }

    public void addPeople(String name, int age) {
        People p = new People(name, age);
        if (p.getAge() >= SENIOR_AGE) {
            queue.offerFirst(p);
        } else {
            queue.offerLast(p);
        }
        p.inQueue();
    }

    public void removePeople() {
        People p = queue.poll();
        p.outQueue();
    }

    public static void main(String[] args) {
        WaitInQueue queue = new WaitInQueue();
        queue.addPeople("asas", 42);
        queue.addPeople("tom", 11);
        queue.addPeople("kevin", 51);
        queue.addPeople("windy", 68);
        queue.addPeople("hello", 22);
        queue.addPeople("bbb", 91);
        queue.addPeople("ccc", 7);
        queue.addPeople("ddd", 34);
        queue.addPeople("eee", 55);

        queue.removePeople();
        queue.removePeople();
        queue.removePeople();
        queue.removePeople();
    }
}
